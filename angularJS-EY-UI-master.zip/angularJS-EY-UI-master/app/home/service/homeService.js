define([], function() {
    'use strict';
        console.log('homeService');
}());
