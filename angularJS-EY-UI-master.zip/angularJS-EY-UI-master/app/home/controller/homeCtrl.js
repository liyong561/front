define([],
    function() {
        'use strict';

        var homeCtrl = ['$scope','$templateCache', function($scope,$templateCache) {
          
        }];

        var homeModule = angular.module('homeModule');
        homeModule.controller('homeCtrl', homeCtrl);


    }());
