define([], function() {
    'use strict';

        console.log('loginService');

}());
